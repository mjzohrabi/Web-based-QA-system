-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 24, 2017 at 09:41 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `stackoverflow`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE IF NOT EXISTS `answers` (
  `a_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `q_id` int(10) unsigned NOT NULL,
  `a_body` text NOT NULL,
  `replier` mediumint(8) unsigned NOT NULL,
  `a_date` datetime NOT NULL,
  `rate` smallint(6) NOT NULL,
  `voters` text NOT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`a_id`, `q_id`, `a_body`, `replier`, `a_date`, `rate`, `voters`) VALUES
(14, 88, '<p>hahahah</p><p>esade</p><p>&nbsp;</p><p>f</p><p>sdf</p><p>&nbsp;</p><p>d</p><p>&nbsp;</p><p>dg</p><p>&nbsp;</p><p>fdgdgdg</p>', 5, '2017-03-12 10:39:04', 1, '2,'),
(15, 88, '<p>yuttutuytu</p><p>oipip</p><p>l;;lk;lkl;l</p><p>&nbsp;</p>', 5, '2017-03-12 10:39:27', 0, ''),
(16, 88, '<p>muahhahhhaha</p><p>yuahhahaha</p>', 5, '2017-03-13 10:34:47', 0, ''),
(38, 88, '<p>tttrrrrrrrrraxtor</p><p>sadsatttr </p>', 5, '2017-03-13 10:36:03', -1, '2,'),
(39, 87, '<p>twesad</p><p>yerssf</p><p>&nbsp;</p>', 2, '2017-03-15 09:35:04', 0, ''),
(40, 1, '<p>ywada</p><p>iouio</p><p>jhklh</p>', 2, '2017-03-15 09:41:03', 0, ''),
(41, 88, '<p>weqewqe</p>', 2, '2017-03-22 14:19:17', 0, ''),
(42, 90, '<p>essssss</p>', 4, '2017-03-27 15:46:01', -2, '5,2,'),
(43, 90, '<p>no manssss</p>', 2, '2017-04-04 08:55:34', 0, ''),
(44, 90, '<p>crap ssss</p>', 2, '2017-04-04 08:58:57', 0, ''),
(45, 89, '<p>ssss</p>', 5, '2017-04-14 17:07:00', 0, ''),
(46, 92, '<p>ffffffffff</p>', 5, '2017-04-14 17:34:16', 0, ''),
(47, 94, '<p>uyi</p>', 4, '2017-05-03 19:38:25', 1, '5,'),
(48, 109, '<p>ssss</p>', 2, '2017-05-23 20:25:40', 0, ''),
(49, 129, '<p>gggvvv</p>', 9, '2017-05-25 11:02:49', 0, ''),
(51, 90, '<p>zzzzzzzzzzz</p>', 4, '2017-05-26 12:10:10', 0, ''),
(52, 129, '', 2, '2017-05-28 15:36:09', 0, ''),
(53, 129, '<p>ssssssssssszzzzzzz</p><p>ahahha</p><p>kev</p>', 4, '2017-05-28 15:46:13', 0, ''),
(54, 133, '<p>www</p>', 13, '2017-06-14 21:49:58', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE IF NOT EXISTS `chat` (
  `ch_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ch_userid` int(10) unsigned NOT NULL,
  `ch_body` varchar(800) NOT NULL,
  `ch_main` varchar(800) NOT NULL,
  `ch_date` datetime NOT NULL,
  PRIMARY KEY (`ch_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=339 ;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`ch_id`, `ch_userid`, `ch_body`, `ch_main`, `ch_date`) VALUES
(105, 2, 'awsdhhh', 'awsdhhh', '2017-06-04 12:45:19'),
(106, 2, ' <div class=''spoil-total''><span onclick=''spoiler("ediaen55fCall_of_Duty_4_Modern_Warfarfarejpg74")'' id=''bbc-spoiler'' class=''chat-btn''>spoil</span><div id=''spoiler-div-ediaen55fCall_of_Duty_4_Modern_Warfarfarejpg74'' class=''none''><img src=''https://upload.wikimedia.org/wikipedia/en/5/5f/Call_of_Duty_4_Modern_Warfare.jpg''></div></div>', ' [spoiler]https://upload.wikimedia.org/wikipedia/en/5/5f/Call_of_Duty_4_Modern_Warfare.jpg[/spoiler]', '2017-06-04 12:46:26'),
(108, 2, 'asdaw', 'asdaw', '2017-06-04 12:48:18'),
(115, 2, '<a class="chat-links" href=http://google.com>http://google.com</a>', 'http://google.com', '2017-06-04 13:01:07'),
(117, 2, '', '[color=red]pox[/color]', '2017-06-04 13:18:35'),
(118, 2, '', '[color=red]pox[/color]', '2017-06-04 13:18:36'),
(125, 2, ' <span style="color:#eee">ssssxxxx</span>', ' [color=#eee]ssssxxxx[/color]', '2017-06-05 13:06:09'),
(126, 2, '<a class="profile2" href=/en/page/profile/2-mehdi>mehdi</a>  <span style="color:lime">FUCK YOU</span>', '@[mehdi]  [color=lime]FUCK YOU[/color]', '2017-06-05 13:08:31'),
(127, 2, ' <span style="color:lime">fuck</span> <span style="color:red">you</span>', ' [color=lime]fuck[/color] [color=red]you[/color]', '2017-06-05 13:12:18'),
(129, 2, '<span style="font:bold">fuck</span>', '[b]fuck[/b]', '2017-06-05 13:19:30'),
(130, 2, '<span style="font:bolder">fuck</span>', '[b]fuck[/b]', '2017-06-05 13:19:56'),
(131, 2, '<span style="font-weight:bolder">fuck</span>', '[b]fuck[/b]', '2017-06-05 13:20:33'),
(132, 2, ' <span style="color:red"><span style="font-weight:bolder">fuck</span></span>', ' [color=red][b]fuck[/b][/color]', '2017-06-05 13:20:48'),
(133, 2, '<span style="font-weight:bolder"><span style="color:lime">shit</span></span>', '[b][color=lime]shit[/color][/b]', '2017-06-05 13:21:42'),
(136, 2, ' <span style="font-weight:bolder">hhh</span> <span style="font-weight:bolder">vvv</span>', ' [b]hhh[/b] [b]vvv[/b]', '2017-06-05 13:27:50'),
(137, 2, ' <span style="color:red">fff</span> <span style="color:lime">gvv</span> <span style="color:pink">pu</span>', ' [color=red]fff[/color] [color=lime]gvv[/color] [color=pink]pu[/color]', '2017-06-05 13:28:17'),
(138, 2, ' <span style="font-weight:bolder">sss</span> <span style="font-weight:bolder">vvv</span> <span style="font-weight:bold">ttt</span>', ' [B]sss[/B] [B]vvv[/B] [b]ttt[/b]', '2017-06-05 13:30:12'),
(139, 2, ' <span style="font-weight:bolder">3333</span> ', ' [B]3333[/B] ', '2017-06-05 13:31:00'),
(140, 2, ' <span style="font-weight:bolder">FUCK</span> <span style="font-weight:bold">FUCK</span> <span style="font-weight:bolder">xxxx</span>', ' [B]FUCK[/B] [b]FUCK[/b] [B]xxxx[/B]', '2017-06-05 13:32:00'),
(141, 2, '<span style="font-weight:500">FUCK</span> <span style="font-weight:bold">FUCK</span> <span style="font-weight:500">xxxx</span>', '[B]FUCK[/B] [b]FUCK[/b] [B]xxxx[/B]', '2017-06-05 13:32:29'),
(142, 2, '<span style="font-weight:800">FUCK</span> <span style="font-weight:bold">FUCK</span> <span style="font-weight:800">xxxx</span>', '[B]FUCK[/B] [b]FUCK[/b] [B]xxxx[/B]', '2017-06-05 13:32:43'),
(145, 2, ' <span class="blink">zxweqr</span>', ' [blink]zxweqr[/blink]', '2017-06-05 13:38:43'),
(146, 2, 'oooooo', 'oooooo', '2017-06-05 13:39:46'),
(147, 2, ' <span class="blink">yrsssrrrrrrrs</span>', ' [blink]yrsssrrrrrrrs[/blink]', '2017-06-05 13:39:54'),
(148, 2, ' <span style="color:red"><span class="blink">ssssssssss</span></span> ', ' [color=red][blink]ssssssssss[/blink][/color] ', '2017-06-05 13:58:46'),
(165, 2, ' <span style="font-weight:800"><span style="color:lime">shit</span></span>', ' [B][color=lime]shit[/color][/B]', '2017-06-05 14:10:47'),
(166, 2, ' <span style="color:red"><span style="font-weight:800">FUCK</span></span> ', ' [color=red][B]FUCK[/B][/color] ', '2017-06-05 14:11:21'),
(171, 2, ' <span class="blink"><span style="font-weight:bold">shitttttttttt</span></span> ', ' [blink][b]shitttttttttt[/b][/blink] ', '2017-06-05 14:14:34'),
(172, 2, ' <span class="blink"><span style="font-weight:800">ssssss</span></span> ', ' [blink][B]ssssss[/B][/blink] ', '2017-06-05 14:14:58'),
(173, 2, ' <span style="color:red"><span class="blink">sssss</span></span> ', ' [color=red][blink]sssss[/blink][/color] ', '2017-06-05 14:16:02'),
(174, 2, ' <span style="color:lime"> <span style="font-weight:bold">sszzzzzzzzzzzzzzzz</span></span>', ' [color=lime] [b]sszzzzzzzzzzzzzzzz[/b][/color]', '2017-06-05 14:16:18'),
(175, 2, ' <span style="font-weight:bold"><span style="color:red">FYYY</span></span> ', ' [b][color=red]FYYY[/color][/b] ', '2017-06-05 14:16:42'),
(176, 2, ' <span style="font-weight:800"><span style="color:aqua">hhhh</span></span> ', ' [B][color=aqua]hhhh[/color][/B] ', '2017-06-05 14:17:06'),
(177, 2, ' <span style="font-weight:800"><span style="color:red">fFFFF</span></span> ', ' [B][color=red]fFFFF[/color][/B] ', '2017-06-05 14:17:23'),
(178, 2, ' <span class="blink"><span style="font-weight:bold">qqqqQQssssQ</span></span> ', ' [blink][b]qqqqQQssssQ[/b][/blink] ', '2017-06-05 14:18:15'),
(184, 2, ' <span class="blink"><span style="font-weight:bold">sssss</span></span> ', ' [rainbow][b]sssss[/b][/rainbow] ', '2017-06-05 14:24:26'),
(190, 2, ' <span style="font-weight:bold"><span class="blink">ssss</span></span> ', ' [b][rainbow]ssss[/rainbow][/b] ', '2017-06-05 14:49:16'),
(197, 2, ' <span class="blink"><span style="font-weight:800">zzzzxxxdd</span></span> ', ' [blink][B]zzzzxxxdd[/B][/blink] ', '2017-06-05 15:05:15'),
(202, 2, ' <div class=''spoil-total''><span onclick=''spoiler("ediaen55fCall_of_Duty_4_Modern_Warfarfarejpg35")'' id=''bbc-spoiler'' class=''chat-btn''>spoil</span><div id=''spoiler-div-ediaen55fCall_of_Duty_4_Modern_Warfarfarejpg35'' class=''none''><img src=''https://upload.wikimedia.org/wikipedia/en/5/5f/Call_of_Duty_4_Modern_Warfare.jpg''></div></div>', ' [img]https://upload.wikimedia.org/wikipedia/en/5/5f/Call_of_Duty_4_Modern_Warfare.jpg[/img]', '2017-06-06 21:11:49'),
(206, 2, ' <pre>hshshshs</pre>', ' [code]hshshshs[/code]', '2017-06-07 23:27:40'),
(212, 2, ' <span style="text-decoration: line-through;">awdsawdw</span>', ' [strike]awdsawdw[/strike]', '2017-06-07 23:34:26'),
(214, 2, ' <span class="blink"> <span style="text-decoration: line-through;">wsss</span></span>', ' [blink] [strike]wsss[/strike][/blink]', '2017-06-07 23:39:06'),
(217, 2, ' <span class="blink"><span style="text-decoration:underline;">wqewwq</span></span> ', ' [blink][u]wqewwq[/u][/blink] ', '2017-06-07 23:42:58'),
(223, 2, 'sad', 'sad', '2017-06-08 01:18:37'),
(224, 2, ' <span style="text-decoration:line-through;">wsx</span>', ' [s]wsx[/s]', '2017-06-08 18:24:43'),
(225, 2, ' <span style="text-decoration:underline;"><a class="chat-links" href=https://google.com>https://google.com</a></span> ', ' [u][url]https://google.com[/url][/u] ', '2017-06-08 18:28:41'),
(226, 2, 'wasddw', 'wasddw', '2017-06-08 19:57:56'),
(237, 2, 'Good Morning Good Morning all Good Morning', 'GM GM all GM', '2017-06-11 11:48:05'),
(238, 2, 'Good Morning Good Morning', 'gm GM', '2017-06-11 11:48:27'),
(240, 2, 'Good Night Good Morning Good Night Good Morning', 'GN gm gn GM', '2017-06-11 11:49:27'),
(241, 2, ' <span style="color:red">Good Morning</span>', ' [color=red]GM[/color]', '2017-06-11 11:53:21'),
(242, 2, ' <span style="color:lime"> <span style="text-decoration:line-through;">swwww</span></span>', ' [color=lime] [s]swwww[/s][/color]', '2017-06-11 11:53:38'),
(250, 2, 'Good Morning Good Morning', 'GM GM', '2017-06-11 16:04:31'),
(251, 2, 'GMG Good Morning Good Morning RWRGMDEE', 'GMG GM GM RWRGMDEE', '2017-06-11 16:05:06'),
(252, 2, 'Good Morning Good Night ', 'GM GN ', '2017-06-11 16:06:20'),
(253, 2, 'GNNN', 'GNNN', '2017-06-11 16:07:31'),
(254, 2, 'Good Morning', 'GM', '2017-06-12 19:46:16'),
(255, 2, 'Good Night', 'GN', '2017-06-12 19:46:18'),
(256, 2, 'GNNN', 'GNNN', '2017-06-12 19:46:21'),
(260, 2, 'xz', 'xz', '2017-06-26 15:49:39'),
(261, 2, 'gsbcxxx', 'gsbcxxx', '2017-06-26 15:50:20'),
(262, 2, 'gttttttt', 'gttttttt', '2017-06-26 15:52:05'),
(263, 2, ' <span style="color:red;">aa</span> <span style="color:green;">aassss</span>', ' [color=red]aa[/color] [color=green]aassss[/color]', '2017-06-27 12:28:38'),
(264, 2, ' <span style="color:lime;">hello</span> ggggg', ' [color=lime]hello[/color] ggggg', '2017-06-27 12:39:16'),
(265, 2, ' <span style="font-weight: bold">ss adasds s</span> <span style="font-weight: bold">xxx  ;''''x</span> gtttt', ' [b]ss adasds s[/b] [b]xxx  ;''''x[/b] gtttt', '2017-06-27 12:52:57'),
(266, 2, ' <span style="font-weight: bolder">www</span> <span style="font-weight: bolder">www</span> <span style="font-weight: bold">www</span>', ' [B]www[/B] [B]www[/B] [b]www[/b]', '2017-06-27 12:54:18'),
(267, 2, ' <span style="background-color: #ddd;color: #444;padding: 2px 4px;">$i=0;$i++</span>', ' [code]$i=0;$i++[/code]', '2017-06-27 12:56:14'),
(274, 2, ' <a class="chat-links" href=http://google.com/translate>http://google.com/translate</a>', ' [url]http://google.com/translate[/url]', '2017-06-27 13:06:30'),
(275, 2, 'sadad', 'sadad', '2017-06-27 13:14:55'),
(276, 2, ' <span style="color:lime;">crap</span>', ' [color=lime]crap[/color]', '2017-06-27 13:15:04'),
(277, 2, ' <span style="text-decoration: line-through"><span style="color:red;">shittttttttttttttt</span></span> ', ' [s][color=red]shittttttttttttttt[/color][/s] ', '2017-06-27 13:16:15'),
(278, 2, ' <span style="text-decoration: line-through">wqqq</span>', ' [s]wqqq[/s]', '2017-06-27 13:16:24'),
(279, 2, ' <span style="text-decoration: underline"> <span style="text-decoration: line-through">XXXXXXXX</span></span>', ' [u] [s]XXXXXXXX[/s][/u]', '2017-06-27 13:17:16'),
(280, 2, ' <span class="blink">hhhhh</span>', ' [blink]hhhhh[/blink]', '2017-06-27 13:18:36'),
(281, 2, '<span style="font-weight: bolder"> <span style="font-style: italic">klaus</span> </span>', '[B] [i]klaus[/i] [/B]', '2017-06-27 13:19:52'),
(282, 2, '  <span style="font-style: italic"><span style="text-decoration: line-through">sdsasd</span></span>', '  [i][s]sdsasd[/s][/i]', '2017-06-27 13:20:07'),
(318, 2, ' <span style="font-weight: bold">waa</span>', ' [b]waa[/b]', '2017-06-27 18:47:36'),
(319, 2, ' <span style="text-decoration: underline"><span style="text-decoration: line-through">w222</span></span> ', ' [u][s]w222[/s][/u] ', '2017-06-27 18:49:02'),
(320, 2, ' <span style="font-weight: bold">wqqq</span>', ' [b]wqqq[/b]', '2017-06-27 19:29:05'),
(321, 2, ' <span style="font-weight: bold">zzzzzzzzz</span>', ' [b]zzzzzzzzz[/b]', '2017-06-27 19:31:05'),
(322, 2, ' <span style="font-weight: bold">qsx</span> <span style="font-weight: bold">za1</span>', ' [b]qsx[/b] [b]za1[/b]', '2017-06-27 19:31:14'),
(324, 2, ' <span style="text-decoration: line-through"><span style="font-weight: bold">@<a class="administrator" href=/en/page/profile/2-mehdi>mehdi</a> </span></span>', ' [s][b]@[mehdi] [/b][/s]', '2017-06-27 19:35:02'),
(325, 2, 'GM', 'GM', '2017-06-27 20:05:44'),
(326, 2, 'GM', 'GM', '2017-06-27 20:05:52'),
(327, 2, 'Good morning', 'GM', '2017-06-27 20:06:24'),
(328, 2, 'GMM', 'GMM', '2017-06-27 20:06:26'),
(329, 2, 'GMM Good morning NG GNNN Good night', 'GMM GM NG GNNN GN', '2017-06-27 20:06:33'),
(330, 2, ' <span style="color:lime;"> <span style="font-weight: bolder">saw</span></span> ', ' [color=lime] [B]saw[/B][/color] ', '2017-06-27 20:13:36'),
(331, 2, ' <span style="color:red;"><span style="font-weight: bold">red</span></span> <span style="color:blue;"><span style="text-decoration: underline"><span style="text-decoration: line-through">sssss</span> </span></span>  ', ' [color=red][b]red[/b][/color] [color=blue][u][s]sssss[/s] [/u][/color]  ', '2017-06-27 20:16:32'),
(332, 4, 'hello', 'hello', '2017-07-01 20:07:18'),
(334, 2, 'hello', 'hello', '2017-09-28 22:14:02'),
(335, 2, ' <span style="background-color: #ddd;color: #444;padding: 2px 4px;">for i=0 sadsad</span>', ' [code]for i=0 sadsad[/code]', '2017-09-28 22:15:18'),
(336, 2, ' <span style="text-decoration: underline">wwwww</span>', ' [u]wwwww[/u]', '2017-09-28 22:15:37'),
(338, 2, ' <span style="color:pink;">goodbur</span>', ' [color=pink]goodbur[/color]', '2017-09-28 22:15:55');

-- --------------------------------------------------------

--
-- Table structure for table `comments_a`
--

CREATE TABLE IF NOT EXISTS `comments_a` (
  `c_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `c_body` varchar(400) NOT NULL,
  `a_id` int(10) unsigned NOT NULL,
  `cmntr` int(10) unsigned NOT NULL,
  `c_date` datetime NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `comments_a`
--

INSERT INTO `comments_a` (`c_id`, `c_body`, `a_id`, `cmntr`, `c_date`) VALUES
(1, 'sssss', 38, 7, '2017-03-14 19:33:07'),
(2, 'sadsadsadzxc', 38, 7, '2017-03-14 19:34:34'),
(3, 'trhhh', 15, 2, '2017-03-15 09:15:56'),
(4, 'saxz', 15, 2, '2017-03-15 09:16:08'),
(5, 'saxz', 15, 2, '2017-03-15 09:16:09'),
(6, 'saxz', 15, 2, '2017-03-15 09:16:12'),
(8, 'crap out saddsad', 15, 2, '2017-03-15 09:25:23'),
(9, '4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444', 15, 2, '2017-03-15 09:29:27'),
(10, 'wq3ew', 38, 2, '2017-03-16 15:06:12'),
(11, 'qqasdw', 38, 2, '2017-03-16 15:09:24'),
(12, 'ttttttttttttttt', 38, 2, '2017-03-16 15:09:59'),
(13, 'sadwqe', 16, 2, '2017-03-22 14:19:34'),
(14, 'hahah', 15, 2, '2017-05-21 23:21:49'),
(19, 'tessst', 54, 2, '2017-06-19 16:47:15'),
(20, '12a', 54, 2, '2017-06-19 16:47:27');

-- --------------------------------------------------------

--
-- Table structure for table `comments_q`
--

CREATE TABLE IF NOT EXISTS `comments_q` (
  `c_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `c_body` varchar(400) NOT NULL,
  `q_id` int(10) unsigned NOT NULL,
  `cmntr` int(10) unsigned NOT NULL,
  `c_date` datetime NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `comments_q`
--

INSERT INTO `comments_q` (`c_id`, `c_body`, `q_id`, `cmntr`, `c_date`) VALUES
(3, 'wwwww', 88, 7, '2017-03-14 11:11:36'),
(4, 'wwwww', 88, 7, '2017-03-14 11:11:36'),
(5, 'wwwww', 88, 7, '2017-03-14 11:11:36'),
(6, 'wwwww', 88, 7, '2017-03-14 11:11:36'),
(7, 'wwwww', 88, 7, '2017-03-14 11:11:36'),
(8, 'crapppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp', 88, 7, '2017-03-14 18:40:19'),
(9, 'crapppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp', 88, 7, '2017-03-14 18:41:19'),
(10, '$records[''q_id'']', 88, 7, '2017-03-14 18:42:39'),
(11, 'crapppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp ', 88, 7, '2017-03-14 18:43:59'),
(12, 'wqdsazx', 88, 7, '2017-03-14 18:45:45'),
(13, 'xzcc', 88, 7, '2017-03-14 18:46:00'),
(14, 'wqewz', 88, 7, '2017-03-14 18:46:20'),
(15, 'sadsad', 88, 7, '2017-03-14 18:46:35'),
(19, 'wqszzzz', 90, 2, '2017-03-16 14:32:28'),
(20, 'qqqw', 90, 2, '2017-03-16 14:33:29'),
(23, 'qqq', 90, 2, '2017-03-22 06:20:43'),
(24, 'sssss', 129, 4, '2017-05-26 12:19:34'),
(25, 'هااهاا', 88, 4, '2017-05-30 10:29:02'),
(26, 'wwwwwxxxxxxx', 133, 13, '2017-06-19 16:01:41');

-- --------------------------------------------------------

--
-- Table structure for table `edited_a`
--

CREATE TABLE IF NOT EXISTS `edited_a` (
  `e_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `a_id` int(10) unsigned NOT NULL,
  `a_body` text NOT NULL,
  `e_date` datetime NOT NULL,
  `editor_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`e_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `edited_a`
--

INSERT INTO `edited_a` (`e_id`, `a_id`, `a_body`, `e_date`, `editor_id`) VALUES
(1, 15, '<p>WHYYYY</p><p>WHYYYY</p><p>&nbsp;</p>', '2017-03-13 12:47:48', 5),
(2, 15, '<p>WHYYYY</p><p>WHYYYY</p><p>&nbsp;shhhh</p>', '2017-03-13 12:49:12', 5),
(3, 15, '<p>WHYYYY</p><p>WHYYYY</p><p>&nbsp;shhhhzxcxsd</p>', '2017-03-13 12:50:14', 5),
(4, 15, '<p>WHYYYY</p><p>WHYYYY</p><p>crappp</p>', '2017-03-13 12:51:32', 5),
(5, 14, '<p>fffffff</p><p>f</p><p>sdf</p><p>&nbsp;</p><p>d</p><p>&nbsp;</p><p>dg</p><p>&nbsp;</p><p>fdgdgdg</p>', '2017-03-13 13:01:54', 5),
(6, 14, '<p>good morning</p>', '2017-03-13 14:04:31', 5),
(7, 38, '<p>wadsaswd</p><p>yi97y8</p>', '2017-03-14 19:34:56', 7),
(8, 15, '<p>yhhhhhhhhhhhhhhhw</p>', '2017-03-14 19:42:35', 7),
(9, 43, '<p>no manssss</p><p>sdadasdgggg</p>', '2017-04-14 21:37:51', 5),
(10, 42, '<p>essssss</p><p>assdad</p>', '2017-04-14 21:51:16', 5),
(11, 43, '<p>no manssss</p><p>no peeee</p>', '2017-04-22 21:29:54', 2),
(12, 41, '<p>after changes</p>', '2017-05-21 23:39:16', 2);

-- --------------------------------------------------------

--
-- Table structure for table `edited_q`
--

CREATE TABLE IF NOT EXISTS `edited_q` (
  `e_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `q_id` int(10) unsigned NOT NULL,
  `q_body` text NOT NULL,
  `e_date` datetime NOT NULL,
  `editor_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`e_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=99 ;

--
-- Dumping data for table `edited_q`
--

INSERT INTO `edited_q` (`e_id`, `q_id`, `q_body`, `e_date`, `editor_id`) VALUES
(85, 88, '<p>all crapssss</p>', '2017-03-13 09:57:17', 5),
(86, 88, '<p>xzczxi been trying harsderfsfFyuiyti</p><p>&nbsp;</p>', '2017-03-13 10:08:07', 5),
(87, 88, '<p>FINAL </p><p>TOKYOoooooooo</p><p>&nbsp;</p>', '2017-03-13 10:31:30', 5),
(88, 88, '<p>FINAL</p><p>TOKYOoooooooo</p><p>hahahaha</p><p>muhahah</p><p>kaneki</p><p>&nbsp;</p>', '2017-03-13 10:40:32', 5),
(89, 88, '<p>owllll</p><p>&nbsp;</p><p>owll</p><p>kaneki</p><p>&nbsp;</p>', '2017-03-13 12:35:13', 5),
(90, 88, '<p>efwashohfd;as</p><p>yres-ytre[ofgde</p><p>xxxxxxx</p><p>&nbsp;</p>', '2017-03-13 13:51:35', 5),
(91, 88, '<p>5r6tyryxdt</p>', '2017-03-13 13:55:10', 5),
(92, 89, '<p>crap </p><p>&nbsp;</p><p>ffff</p>', '2017-03-15 18:13:53', 2),
(93, 88, '<p>crap</p><p>man</p><p>ssss</p>', '2017-04-01 08:14:11', 2),
(94, 89, '<p>oh mannnnnn!!!!</p><p>ffff</p>', '2017-04-13 19:58:29', 5),
(95, 90, '<p>was empty!!!!</p>', '2017-04-13 20:00:03', 5),
(96, 93, '<p>no man</p><p>&nbsp;</p><p>nooo</p><p>&nbsp;</p>', '2017-04-13 17:45:14', 5),
(97, 88, '<p>crap</p><p>after change</p>', '2017-06-13 23:40:20', 2),
(98, 88, '<p>crap</p><p>after change</p><p>division</p>', '2017-06-19 16:00:16', 13);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `q_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `q_name` varchar(200) NOT NULL,
  `q_body` text NOT NULL,
  `asker` mediumint(8) unsigned NOT NULL,
  `repliers` text NOT NULL,
  `q_date` datetime NOT NULL,
  `rate` smallint(6) NOT NULL,
  `voters` text NOT NULL,
  `tag1` varchar(20) NOT NULL,
  `tag2` varchar(20) NOT NULL,
  `tag3` varchar(20) NOT NULL,
  `tag4` varchar(20) NOT NULL,
  `tag5` varchar(20) NOT NULL,
  `correct_answer` int(10) unsigned NOT NULL,
  `views` int(10) unsigned NOT NULL,
  PRIMARY KEY (`q_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=134 ;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`q_id`, `q_name`, `q_body`, `asker`, `repliers`, `q_date`, `rate`, `voters`, `tag1`, `tag2`, `tag3`, `tag4`, `tag5`, `correct_answer`, `views`) VALUES
(56, 'how can i do that??', '<p>simplescxdasdsadas simplescxdasdsadas  simplescxdasdsadas simplescxdasdsadas simplescxdasdsadas simplescxdasdsadas simplescxdasdsadas simplescxdasdsadas simplescxdasdsadas simplescxdasdsadas simplescxdasdsadas simplescxdasdsadas simplescxdasdsadas</p>', 2, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(57, 'how can i do that??', '<p>simplescxdasdsadas</p>', 4, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(58, 'how can i do that??', '<p>simplescxdasdsadas</p>', 4, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(59, 'how can i do that??', '<p>simplescxdasdsadas</p>', 4, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(60, 'how can i do that??', '<p>simplescxdasdsadas</p>', 5, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(61, 'how can i do that??', '<p>simplescxdasdsadas</p>', 5, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(62, 'how can i do that??', '<p>simplescxdasdsadas</p>', 5, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(63, 'how can i do that??', '<p>simplescxdasdsadas</p>', 2, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 1),
(64, 'how can i do that??', '<p>simplescxdasdsadas</p>', 2, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 1),
(65, 'how can i do that??', '<p>simplescxdasdsadas</p>', 4, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(66, 'how can i do that??', '<p>simplescxdasdsadas</p>', 4, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(67, 'how can i do that??', '<p>simplescxdasdsadas</p>', 4, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(68, 'how can i do that??', '<p>simplescxdasdsadas</p>', 4, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(69, 'how can i do that??', '<p>simplescxdasdsadas</p>', 4, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(70, 'how can i do that??', '<p>simplescxdasdsadas</p>', 4, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(71, 'how can i do that??', '<p>simplescxdasdsadas</p>', 8, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(72, 'how can i do that??', '<p>simplescxdasdsadas</p>', 8, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(73, 'how can i do that??', '<p>simplescxdasdsadas</p>', 8, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(74, 'how can i do that??', '<p>simplescxdasdsadas</p>', 8, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(75, 'how can i do that??', '<p>simplescxdasdsadas</p>', 5, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 1),
(76, 'how can i do that??', '<p>simplescxdasdsadas</p>', 5, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(77, 'how can i do that??', '<p>simplescxdasdsadas</p>', 2, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(78, 'how can i do that??', '<p>simplescxdasdsadas</p>', 2, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 1),
(79, 'how can i do that??', '<p>simplescxdasdsadas</p>', 6, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(80, 'how can i do that??', '<p>simplescxdasdsadas</p>', 7, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(81, 'how can i do that??', '<p>simplescxdasdsadas</p>', 8, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(82, 'how can i do that??', '<p>simplescxdasdsadas</p>', 8, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(83, 'how can i do that??', '<p>simplescxdasdsadas</p>', 4, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 0),
(84, 'how can i do that??', '<p>simplescxdasdsadas</p>', 4, '', '0000-00-00 00:00:00', 0, '', 'python', 'jquery', 'sql', 'php', '', 0, 1),
(85, 'how to make a modal ???', '<p>i been trying hard but couldnt make it...i been trying hard but couldnt make it...i been trying hard but couldnt make it...i been trying hard but couldnt make it...i been trying hard but couldnt make it...</p><p>sdasdsdasa</p><p>&nbsp;</p><ul><li>make a div</li><li>invisible it</li><li>sadsad</li><li>fds</li><li>f</li><li>r</li><li>etreyr</li><li>eye</li></ul><div>sadsadsadsd</div><div>&nbsp;</div><ol style="list-style-type: lower-roman;"><li>sadsadsd</li><li>dsf</li><li>rte</li></ol><p>tre</p><p>yre</p>', 4, '', '2017-03-11 19:30:00', -1, '7,', 'php', 'javascript', '', '', '', 0, 8),
(86, 'gggg   ??', '<p>aswdzxx</p>', 5, '', '2017-03-12 09:00:19', 0, '', 'fresrew', 'dfgtrt', '', '', '', 0, 0),
(87, 'ewrewr', '<p>fggdg</p>', 5, '2,', '2017-03-12 09:10:12', 0, '', '', '', '', '', '', 0, 5),
(88, 'ttttttt  simplescxdasdsadas simplescxdasdsadas simplescxdasdsadas simplescxdasdsadas   ??', '<p>xzczxi been trying hard but couldnt make iti been trying hard but couldnt make iti been trying hard but couldnt make iti been trying hard but couldnt make iti been trying hard but couldnt make iti been trying hard but couldnt make iti been trying hard but couldnt make iti been trying hard but couldnt make iti been trying hard but couldnt make itc</p>', 5, '5,5,5,5,2,4,', '2017-03-12 09:10:49', 2, '4,2,', 'dsfe', 'ytu', '', '', '', 0, 221),
(89, 'shii     ??', '<p>rtrtr</p>', 5, '5,', '2017-03-15 18:13:23', 0, '', '', '', '', '', '', 0, 16),
(90, 'kesporeot es pktposeres tr[tkset    ?', '', 2, '4,2,2,4,', '2017-03-15 18:14:22', 1, '5,', '', '', '', '', '', 0, 171),
(91, 'gkgk{jp}', '<p>yy777</p><p>o9pu</p>', 4, '', '2017-04-13 17:33:29', 1, '7,', '', '', '', '', '', 0, 6),
(92, 'fsfdsdsf', '<p>gdsgdsgs</p>', 2, '5,', '2017-04-13 17:00:03', 0, '', 'php', '', '', '', '', 0, 2),
(93, 'hhhhhhhh', '<p>fgdg</p>', 2, '', '2017-04-13 15:42:26', 0, '', '', '', '', '', '', 0, 4),
(94, 'time zone in c++ and c# and {english}   ???', '<p>i want to know</p><p>&nbsp;</p><p>&nbsp;</p><p>sadsadsda</p>', 5, '4,', '2017-04-14 17:58:03', 1, '4,', 'php', 'c++', 'c#', '', '', 0, 17),
(95, 'eee', '<p>ffff</p>', 4, '', '2017-05-03 19:28:41', 0, '', '', '', '', '', '', 0, 0),
(96, 'rrrrr', '<p>fgfg</p>', 4, '', '2017-05-03 19:29:06', 0, '', 'ggx', '', '', '', '', 0, 0),
(97, 'ttttt', '<p>jjjj</p>', 4, '', '2017-05-03 19:29:27', 0, '', 'dfddf', '', '', '', '', 0, 0),
(99, '555', '<p>hhhh</p>', 4, '', '2017-05-03 19:33:27', 0, '', '', 'j', '', '', '', 0, 0),
(100, 'hgj', '<p>jhk</p>', 4, '', '2017-05-03 19:33:50', 0, '', '', '', '', '', '', 0, 3),
(101, 'khkkhhk', '<p>ggggggggg''u68</p><p>oiuouoiio</p>', 2, '', '2017-05-11 12:09:02', 0, '', 'php', 'javascript', '', '', '', 0, 0),
(102, 'hhhhh', '<p>kyyui</p>', 2, '', '2017-05-11 12:09:37', 0, '', 'php', 'javascript', '', '', '', 0, 0),
(103, 'jytju', '<p>kyuyku</p>', 2, '', '2017-05-11 13:27:13', 0, '', 'php', 'javascript', '', '', '', 0, 0),
(104, 'dsasd...!', '<p>sad</p>', 2, '', '2017-05-23 20:15:09', 0, '', 'sad', '', '', '', '', 0, 0),
(105, 'wad...!!!', '<p>sadsad</p>', 2, '', '2017-05-23 20:16:12', 0, '', '', '', '', '', '', 0, 0),
(106, 'asdwa!sdsad...', '<p>gfdgds</p>', 2, '', '2017-05-23 20:16:23', 0, '', 'sdsd', '', '', '', '', 0, 0),
(107, 'asdasd...!!', '<p>sdsa</p>', 2, '', '2017-05-23 20:17:53', 0, '', 'sda', '', '', '', '', 0, 1),
(108, 'dasd'' '' " "', '<p>sadas</p>', 2, '', '2017-05-23 20:19:57', 0, '', '', '', '', '', '', 0, 2),
(109, 'sads'' '' " ', '<p>sadsdad</p>', 2, '2,', '2017-05-23 20:23:31', 0, '', '', '', '', '', '', 0, 3),
(110, 'xd''"!!.'')(', '<p>vvv</p>', 2, '', '2017-05-23 20:27:18', 0, '', 'dd', '', '', '', '', 0, 1),
(111, 'sdd.\\', '<p>sad</p>', 2, '', '2017-05-23 20:28:33', 0, '', '', '', '', '', '', 0, 0),
(112, 'dgfdg...', '<p>gf</p>', 2, '', '2017-05-23 20:29:14', 0, '', 'hf', '', '', '', '', 0, 1),
(113, 'sad..!)()()\\', '<p>sad</p>', 2, '', '2017-05-23 20:36:02', 0, '', 'sad', '', '', '', '', 0, 0),
(114, 'sadsd\\', '<p>sad</p>', 2, '', '2017-05-23 20:36:18', 0, '', 'sad', '', '', '', '', 0, 0),
(115, 'adsda\\', '<p>asd</p>', 2, '', '2017-05-23 20:39:24', 0, '', '', '', '', '', '', 0, 0),
(116, 'zxcasd\\\\\\\\///\\/\\', '<p>sad</p>', 2, '', '2017-05-23 20:41:01', 0, '', '', '', '', '', '', 0, 0),
(117, 'asd\\\\\\\\///\\//\\\\!...()(){}[]', '<p>sad</p>', 2, '', '2017-05-23 20:42:52', 0, '', '', '', '', '', '', 0, 1),
(118, 'sss\\', '<p>sad</p>', 2, '', '2017-05-23 20:44:30', 0, '', '', '', '', '', '', 0, 0),
(119, 'ccc////', '<p>dd</p>', 2, '', '2017-05-23 20:44:37', 0, '', '', '', '', '', '', 0, 1),
(120, 'sss*', '<p>ss</p>', 2, '', '2017-05-23 20:45:05', 0, '', '', '', '', '', '', 0, 1),
(121, 'ff?#+][}{{}[].!())(\\\\\\\\\\\\\\\\\\\\\\//////\\\\//''\\\\''//"\\/"  /\\/\\', '<p>bbb</p>', 2, '', '2017-05-23 20:52:10', 0, '', 'dss', 'fdg', 'fdg', 'fgh', 'fd', 0, 1),
(122, 'tyr', '<p>jytu</p>', 2, '', '2017-05-23 20:55:35', 0, '', 'aa', 'c', '', '', '', 0, 0),
(123, 'ggg', '<p>htrhr</p>', 2, '', '2017-05-23 20:55:59', 0, '', 'ff', 'hh', 'tt', 'rr', 'ee', 0, 0),
(124, 'test?+//\\/\\/"/\\''''''\\+[]][()()))(\\\\/{}*&^%$@!!', '<p>xxzc</p>', 2, '', '2017-05-23 21:01:26', 0, '', '', '', '', '', '', 0, 4),
(125, 'test?+//\\/\\/"/\\''''''\\+[]][()()))(\\\\/{}*&^%$@!!><=_-', '<p>ccc</p>', 2, '', '2017-05-23 21:05:03', 0, '', '', '', '', '', '', 0, 2),
(126, 'test?+//\\/\\/"/\\''''''\\+-[]][()()))(\\\\/{}*&^%$@!!><=_-', '<p>xx</p>', 2, '', '2017-05-23 21:05:34', 0, '', '', '', '', '', '', 0, 1),
(127, 'test-?+//\\/\\/"/\\''''''\\+[]][()()))(\\\\/{}*&^%$@!!><=_-', '<p>hyy</p>', 2, '', '2017-05-23 21:05:48', 0, '', '', '', '', '', '', 0, 3),
(128, 'sadjii-sda', '<p>vv</p>', 2, '', '2017-05-23 21:06:09', 0, '', '', '', '', '', '', 0, 2),
(129, 'test- -?+//\\/\\/"/\\''''''\\+[]][()()))(\\\\/{}*&^%$@!!><=_-', '<p>xx</p>', 2, '9,2,4,', '2017-05-23 21:08:32', 0, '', '', '', '', '', '', 49, 62),
(130, 'سلامم', '<p>یسشیسشیسشیشسی یسشیسشیسشیشسی یسشیسشیسشیشسی یسشیسشیسشیشسی یسشیسشیسشیشسی یسشیسشیسشیشسی یسشیسشیسشیشسی یسشیسشیسشیشسی </p>', 4, '', '2017-05-26 12:28:47', 0, '', 'php', 'dasd', 'asd', '', '', 0, 62),
(131, 'سلام)(**&^%%$#}{}{}چج', '<p>یسیبس</p>', 4, '', '2017-05-26 12:57:20', 1, '5,', '', '', '', '', '', 0, 25),
(132, 'HElloo My', '<p>asdsa</p>', 2, '', '2017-06-08 16:35:13', 0, '', '', '', '', '', '', 0, 8),
(133, 'swwwwwww', '<p>sadsad</p>', 5, '13,', '2017-06-14 21:08:16', 0, '', 'php', '', 'javascript', 'rrrrrrrrrrrrrrrrrrrr', '', 0, 47);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(25) NOT NULL,
  `password` varchar(40) NOT NULL,
  `class` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `register_time` datetime NOT NULL,
  `about` text NOT NULL,
  `answered_q` text NOT NULL,
  `views` int(10) unsigned NOT NULL,
  `rate` float NOT NULL,
  `raters_id` text NOT NULL,
  `reputation` int(11) NOT NULL,
  `notification` text NOT NULL,
  `notf_num` smallint(5) unsigned NOT NULL,
  `fav_tags` text NOT NULL,
  `access` tinyint(3) unsigned NOT NULL DEFAULT '10',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `password`, `class`, `email`, `register_time`, `about`, `answered_q`, `views`, `rate`, `raters_id`, `reputation`, `notification`, `notf_num`, `fav_tags`, `access`) VALUES
(2, 'mehdi', '2a2b14da660d6aa3f84908d6172cd82b', 'administrator', 'example@gmail.com', '2017-02-16 15:27:05', '<p><span class="nth-about-usr">This user has not written anything about him/her self yet!</span></p>', '87,88,90,90,109,129,', 533, 5, '4,5,', 10, '5/90/1,', 0, 'html,php,javascript,css,', 100),
(4, 'king', '2a2b14da660d6aa3f84908d6172cd82b', 'headadmin', 'example2@gmail.com', '2017-02-16 15:38:15', '<p>ffgg</p>', '90,94,90,129,', 454, 5, '2,', 24, '7/91/1,7/85/0,5/94/1,5/131/1,', 0, '', 80),
(5, 'test1', '2a2b14da660d6aa3f84908d6172cd82b', 'admin', 'example3@gmail.com', '2017-03-12 10:20:54', '', '88,88,88,88,89,92,', 225, 4.33333, '2,7,4,', 38, '4/88/1,2/88/1,4/94/1,', 0, 'php,html,js,css,python,pdf,sql', 60),
(6, 'wwwxxx', '2a2b14da660d6aa3f84908d6172cd82b', 'user', 'dfsfdsd@gmail.com', '2017-03-12 10:22:36', '', '', 0, 0, '', 0, '', 0, '', 10),
(7, 'test2', '2a2b14da660d6aa3f84908d6172cd82b', 'user', 'test1@gmail.com', '2017-03-12 10:24:54', '', '', 1, 0, '', 0, '', 0, '', 10),
(8, 'test3', '2a2b14da660d6aa3f84908d6172cd82b', 'user', 'esfsaefa@sdgds', '2017-03-12 10:25:07', '', '', 0, 0, '', 0, '', 0, '', 10),
(9, 'jack44', '2a2b14da660d6aa3f84908d6172cd82b', 'user', 'test6@gmail.com', '2017-05-25 11:02:08', '<p>asdda</p>', '129,', 79, 0, '', 0, '', 0, 'javascript,php,', 10),
(10, 'wewwww', '2a2b14da660d6aa3f84908d6172cd82b', 'user', 'sad@gmail.com', '2017-06-01 13:58:53', '', '', 0, 0, '', 0, '', 0, '', 10),
(11, 'tttttt', '2a2b14da660d6aa3f84908d6172cd82b', 'user', 'sdw@gg.vn', '2017-06-06 20:30:54', '', '', 0, 0, '', 0, '', 0, '', 10),
(12, 'ggggggggggggggggggggggggg', '2a2b14da660d6aa3f84908d6172cd82b', 'user', 'ee@g.h', '2017-06-14 20:59:22', '', '', 2, 0, '', 0, '', 0, '', 10),
(13, 'ggggggggggrrrrrrrrrrrrrrr', '2a2b14da660d6aa3f84908d6172cd82b', 'user', 'e@t.u', '2017-06-14 21:00:48', '', '133,', 11, 0, '', 0, '', 0, 'javascript,php,', 10);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
